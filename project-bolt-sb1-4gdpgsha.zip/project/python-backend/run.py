#!/usr/bin/env python3
"""
SPHINX CAFE Backend Server
Run this file to start the backend server
"""
import os
import sys
import subprocess

def install_requirements():
    """Install required packages"""
    print("Installing required packages...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])

def run_server():
    """Run the Flask server"""
    print("Starting SPHINX CAFE Backend Server...")
    print("Server will be available at: http://localhost:5000")
    print("Press Ctrl+C to stop the server")
    
    try:
        from app import app, init_db
        init_db()
        app.run(debug=True, host='0.0.0.0', port=5000)
    except ImportError:
        print("Error: Required packages not installed.")
        print("Installing packages...")
        install_requirements()
        print("Please run the script again.")

if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'install':
        install_requirements()
    else:
        run_server()