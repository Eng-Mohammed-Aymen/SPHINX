from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
import datetime
import os
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
from functools import wraps

app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = 'sphinx-cafe-secret-key-2024'

# Database initialization
def init_db():
    conn = sqlite3.connect('sphinx_cafe.db')
    cursor = conn.cursor()
    
    # Create tables
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS menu_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            name_en TEXT NOT NULL,
            price REAL NOT NULL,
            category TEXT NOT NULL,
            description TEXT,
            image_url TEXT,
            is_popular BOOLEAN DEFAULT 0,
            is_available BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name TEXT,
            total_amount REAL NOT NULL,
            tax_amount REAL NOT NULL,
            payment_method TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER,
            menu_item_id INTEGER,
            quantity INTEGER NOT NULL,
            price REAL NOT NULL,
            FOREIGN KEY (order_id) REFERENCES orders (id),
            FOREIGN KEY (menu_item_id) REFERENCES menu_items (id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key TEXT UNIQUE NOT NULL,
            value TEXT NOT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Insert default admin user
    admin_password = generate_password_hash('admin123')
    cursor.execute('''
        INSERT OR IGNORE INTO users (username, email, password_hash, role)
        VALUES ('admin', 'admin@sphinxcafe.com', ?, 'admin')
    ''', (admin_password,))
    
    # Insert sample menu items
    sample_items = [
        ('إسبريسو', 'Espresso', 15.0, 'hot', 'قهوة إسبريسو إيطالية أصيلة', '', 1, 1),
        ('كابتشينو', 'Cappuccino', 20.0, 'hot', 'قهوة كابتشينو كريمية مع رغوة الحليب', '', 1, 1),
        ('لاتيه', 'Latte', 22.0, 'hot', 'قهوة لاتيه ناعمة مع الحليب المبخر', '', 0, 1),
        ('قهوة مثلجة', 'Iced Coffee', 18.0, 'cold', 'قهوة باردة منعشة', '', 0, 1),
        ('فرابيه', 'Frappe', 28.0, 'cold', 'مشروب فرابيه بارد ومنعش', '', 1, 1),
        ('كرواسون', 'Croissant', 12.0, 'pastry', 'كرواسون فرنسي طازج', '', 0, 1),
        ('مافن التوت', 'Blueberry Muffin', 15.0, 'pastry', 'مافن التوت الطازج', '', 1, 1),
    ]
    
    cursor.executemany('''
        INSERT OR IGNORE INTO menu_items 
        (name, name_en, price, category, description, image_url, is_popular, is_available)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', sample_items)
    
    # Insert default settings
    default_settings = [
        ('store_name', 'SPHINX CAFE'),
        ('tax_rate', '14'),
        ('currency', 'EGP'),
        ('language', 'ar'),
        ('theme', 'amber'),
    ]
    
    cursor.executemany('''
        INSERT OR IGNORE INTO settings (key, value)
        VALUES (?, ?)
    ''', default_settings)
    
    conn.commit()
    conn.close()

# Token required decorator
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'message': 'Token is missing'}), 401
        
        try:
            if token.startswith('Bearer '):
                token = token[7:]
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
            current_user_id = data['user_id']
        except:
            return jsonify({'message': 'Token is invalid'}), 401
        
        return f(current_user_id, *args, **kwargs)
    
    return decorated

# Authentication routes
@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    
    if not username or not password:
        return jsonify({'message': 'Username and password required'}), 400
    
    conn = sqlite3.connect('sphinx_cafe.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
    user = cursor.fetchone()
    conn.close()
    
    if user and check_password_hash(user[3], password):
        token = jwt.encode({
            'user_id': user[0],
            'username': user[1],
            'role': user[4],
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
        }, app.config['SECRET_KEY'])
        
        return jsonify({
            'token': token,
            'user': {
                'id': user[0],
                'username': user[1],
                'email': user[2],
                'role': user[4]
            }
        })
    
    return jsonify({'message': 'Invalid credentials'}), 401

# Menu routes
@app.route('/api/menu', methods=['GET'])
def get_menu():
    conn = sqlite3.connect('sphinx_cafe.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM menu_items WHERE is_available = 1')
    items = cursor.fetchall()
    conn.close()
    
    menu_items = []
    for item in items:
        menu_items.append({
            'id': item[0],
            'name': item[1],
            'name_en': item[2],
            'price': item[3],
            'category': item[4],
            'description': item[5],
            'image_url': item[6],
            'is_popular': bool(item[7]),
            'is_available': bool(item[8])
        })
    
    return jsonify(menu_items)

@app.route('/api/menu', methods=['POST'])
@token_required
def add_menu_item(current_user_id):
    data = request.get_json()
    
    conn = sqlite3.connect('sphinx_cafe.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO menu_items (name, name_en, price, category, description, image_url, is_popular)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (
        data['name'], data['name_en'], data['price'], data['category'],
        data.get('description', ''), data.get('image_url', ''), 
        data.get('is_popular', False)
    ))
    conn.commit()
    conn.close()
    
    return jsonify({'message': 'Menu item added successfully'}), 201

# Orders routes
@app.route('/api/orders', methods=['POST'])
def create_order():
    data = request.get_json()
    
    conn = sqlite3.connect('sphinx_cafe.db')
    cursor = conn.cursor()
    
    # Create order
    cursor.execute('''
        INSERT INTO orders (customer_name, total_amount, tax_amount, payment_method, status)
        VALUES (?, ?, ?, ?, ?)
    ''', (
        data.get('customer_name', 'Guest'),
        data['total_amount'], data['tax_amount'],
        data['payment_method'], 'completed'
    ))
    
    order_id = cursor.lastrowid
    
    # Add order items
    for item in data['items']:
        cursor.execute('''
            INSERT INTO order_items (order_id, menu_item_id, quantity, price)
            VALUES (?, ?, ?, ?)
        ''', (order_id, item['id'], item['quantity'], item['price']))
    
    conn.commit()
    conn.close()
    
    return jsonify({'message': 'Order created successfully', 'order_id': order_id}), 201

@app.route('/api/orders', methods=['GET'])
@token_required
def get_orders(current_user_id):
    conn = sqlite3.connect('sphinx_cafe.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT o.*, COUNT(oi.id) as item_count
        FROM orders o
        LEFT JOIN order_items oi ON o.id = oi.order_id
        GROUP BY o.id
        ORDER BY o.created_at DESC
        LIMIT 50
    ''')
    orders = cursor.fetchall()
    conn.close()
    
    order_list = []
    for order in orders:
        order_list.append({
            'id': order[0],
            'customer_name': order[1],
            'total_amount': order[2],
            'tax_amount': order[3],
            'payment_method': order[4],
            'status': order[5],
            'created_at': order[6],
            'item_count': order[7]
        })
    
    return jsonify(order_list)

# Analytics routes
@app.route('/api/analytics/dashboard', methods=['GET'])
@token_required
def get_dashboard_analytics(current_user_id):
    period = request.args.get('period', 'today')
    
    conn = sqlite3.connect('sphinx_cafe.db')
    cursor = conn.cursor()
    
    if period == 'today':
        date_filter = "DATE(created_at) = DATE('now')"
    else:
        date_filter = "DATE(created_at) >= DATE('now', 'start of month')"
    
    # Get total revenue
    cursor.execute(f'SELECT SUM(total_amount) FROM orders WHERE {date_filter}')
    revenue = cursor.fetchone()[0] or 0
    
    # Get order count
    cursor.execute(f'SELECT COUNT(*) FROM orders WHERE {date_filter}')
    orders = cursor.fetchone()[0] or 0
    
    # Get customer count (unique customers)
    cursor.execute(f'SELECT COUNT(DISTINCT customer_name) FROM orders WHERE {date_filter}')
    customers = cursor.fetchone()[0] or 0
    
    # Get popular items
    cursor.execute('''
        SELECT mi.name, SUM(oi.quantity) as sales, SUM(oi.quantity * oi.price) as revenue
        FROM order_items oi
        JOIN menu_items mi ON oi.menu_item_id = mi.id
        JOIN orders o ON oi.order_id = o.id
        WHERE DATE(o.created_at) >= DATE('now', '-30 days')
        GROUP BY mi.id, mi.name
        ORDER BY sales DESC
        LIMIT 5
    ''')
    popular_items = cursor.fetchall()
    
    conn.close()
    
    return jsonify({
        'revenue': revenue,
        'orders': orders,
        'customers': customers,
        'avg_order_value': revenue / orders if orders > 0 else 0,
        'popular_items': [
            {'name': item[0], 'sales': item[1], 'revenue': item[2]}
            for item in popular_items
        ]
    })

# Settings routes
@app.route('/api/settings', methods=['GET'])
@token_required
def get_settings(current_user_id):
    conn = sqlite3.connect('sphinx_cafe.db')
    cursor = conn.cursor()
    cursor.execute('SELECT key, value FROM settings')
    settings = cursor.fetchall()
    conn.close()
    
    settings_dict = {setting[0]: setting[1] for setting in settings}
    return jsonify(settings_dict)

@app.route('/api/settings', methods=['PUT'])
@token_required
def update_settings(current_user_id):
    data = request.get_json()
    
    conn = sqlite3.connect('sphinx_cafe.db')
    cursor = conn.cursor()
    
    for key, value in data.items():
        cursor.execute('''
            INSERT OR REPLACE INTO settings (key, value, updated_at)
            VALUES (?, ?, ?)
        ''', (key, str(value), datetime.datetime.now()))
    
    conn.commit()
    conn.close()
    
    return jsonify({'message': 'Settings updated successfully'})

# Health check
@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy', 'timestamp': datetime.datetime.now().isoformat()})

if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)