import React from 'react';
import { ArrowRight, Star, Clock, Wifi } from 'lucide-react';

const Hero: React.FC = () => {
  const features = [
    'أجود أنواع القهوة المحمصة طازجة',
    'مخبوزات يومية طازجة',
    'مشروبات باردة منعشة',
    'أجواء مريحة ومميزة',
    'خدمة عملاء ممتازة',
    'واي فاي مجاني',
    'موقع مثالي في قلب المدينة',
    'أسعار منافسة وجودة عالية',
  ];

  return (
    <div className="relative min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-amber-100 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div 
          className="w-full h-full bg-repeat"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23D97706' fill-opacity='0.4'%3E%3Ccircle cx='30' cy='30' r='4'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
        <div className="text-center">
          {/* Main Title */}
          <h1 className="text-6xl md:text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-800 via-amber-600 to-amber-800 mb-6 tracking-tight">
            SPHINX
          </h1>
          
          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-amber-700 mb-8 max-w-2xl mx-auto leading-relaxed">
            تجربة قهوة استثنائية في أجواء مستوحاة من عظمة الحضارة المصرية
          </p>

          {/* Features Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 max-w-4xl mx-auto">
            <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-amber-200">
              <Star className="h-8 w-8 text-amber-500 mx-auto mb-3" />
              <h3 className="text-lg font-semibold text-amber-800 mb-2">جودة عالية</h3>
              <p className="text-amber-600">أجود أنواع القهوة والمشروبات</p>
            </div>
            
            <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-amber-200">
              <Clock className="h-8 w-8 text-amber-500 mx-auto mb-3" />
              <h3 className="text-lg font-semibold text-amber-800 mb-2">خدمة سريعة</h3>
              <p className="text-amber-600">تحضير سريع وخدمة ممتازة</p>
            </div>
            
            <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-amber-200">
              <Wifi className="h-8 w-8 text-amber-500 mx-auto mb-3" />
              <h3 className="text-lg font-semibold text-amber-800 mb-2">أجواء مريحة</h3>
              <p className="text-amber-600">مكان مثالي للعمل والاسترخاء</p>
            </div>
          </div>

          {/* Call to Action */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-gradient-to-r from-amber-600 to-amber-700 text-white px-8 py-3 rounded-full font-semibold text-lg hover:from-amber-700 hover:to-amber-800 transition-all duration-300 shadow-lg hover:shadow-xl flex items-center justify-center group">
              اطلب الآن
              <ArrowRight className="h-5 w-5 mr-2 group-hover:translate-x-1 transition-transform" />
            </button>
            
            <button className="border-2 border-amber-600 text-amber-600 px-8 py-3 rounded-full font-semibold text-lg hover:bg-amber-600 hover:text-white transition-all duration-300">
              تصفح القائمة
            </button>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute top-1/4 left-10 w-20 h-20 bg-amber-200 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute bottom-1/4 right-10 w-16 h-16 bg-orange-200 rounded-full opacity-20 animate-pulse delay-1000"></div>
      </div>

      {/* Infinite Scrolling Text */}
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-r from-amber-800 via-amber-700 to-amber-800 text-white py-4 overflow-hidden">
        <div className="animate-scroll whitespace-nowrap">
          <span className="text-lg font-medium">
            {features.map((feature, index) => (
              <span key={index} className="mx-8">
                ✨ {feature}
              </span>
            ))}
            {features.map((feature, index) => (
              <span key={`repeat-${index}`} className="mx-8">
                ✨ {feature}
              </span>
            ))}
          </span>
        </div>
      </div>
    </div>
  );
};

export default Hero;