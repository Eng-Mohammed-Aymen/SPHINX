import React, { useState } from 'react';
import { Plus, Search, Filter } from 'lucide-react';

interface MenuItem {
  id: number;
  name: string;
  nameEn: string;
  price: number;
  category: string;
  description: string;
  image: string;
  popular?: boolean;
}

interface MenuProps {
  onAddToCart: (item: MenuItem) => void;
}

const Menu: React.FC<MenuProps> = ({ onAddToCart }) => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const menuItems: MenuItem[] = [
    // Hot Drinks
    {
      id: 1,
      name: 'إسبريسو',
      nameEn: 'Espresso',
      price: 15,
      category: 'hot',
      description: 'قهوة إسبريسو إيطالية أصيلة',
      image: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=300',
      popular: true,
    },
    {
      id: 2,
      name: 'كابتشينو',
      nameEn: 'Cappuccino',
      price: 20,
      category: 'hot',
      description: 'قهوة كابتشينو كريمية مع رغوة الحليب',
      image: 'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg?auto=compress&cs=tinysrgb&w=300',
      popular: true,
    },
    {
      id: 3,
      name: 'لاتيه',
      nameEn: 'Latte',
      price: 22,
      category: 'hot',
      description: 'قهوة لاتيه ناعمة مع الحليب المبخر',
      image: 'https://images.pexels.com/photos/324028/pexels-photo-324028.jpeg?auto=compress&cs=tinysrgb&w=300',
    },
    {
      id: 4,
      name: 'موكا',
      nameEn: 'Mocha',
      price: 25,
      category: 'hot',
      description: 'قهوة موكا بالشوكولاتة الساخنة',
      image: 'https://images.pexels.com/photos/851555/pexels-photo-851555.jpeg?auto=compress&cs=tinysrgb&w=300',
    },
    // Cold Drinks
    {
      id: 5,
      name: 'قهوة مثلجة',
      nameEn: 'Iced Coffee',
      price: 18,
      category: 'cold',
      description: 'قهوة باردة منعشة',
      image: 'https://images.pexels.com/photos/1233415/pexels-photo-1233415.jpeg?auto=compress&cs=tinysrgb&w=300',
    },
    {
      id: 6,
      name: 'فرابيه',
      nameEn: 'Frappe',
      price: 28,
      category: 'cold',
      description: 'مشروب فرابيه بارد ومنعش',
      image: 'https://images.pexels.com/photos/1417945/pexels-photo-1417945.jpeg?auto=compress&cs=tinysrgb&w=300',
      popular: true,
    },
    {
      id: 7,
      name: 'سموثي المانجو',
      nameEn: 'Mango Smoothie',
      price: 30,
      category: 'cold',
      description: 'سموثي المانجو الطازج',
      image: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=300',
    },
    // Pastries
    {
      id: 8,
      name: 'كرواسون',
      nameEn: 'Croissant',
      price: 12,
      category: 'pastry',
      description: 'كرواسون فرنسي طازج',
      image: 'https://images.pexels.com/photos/1775043/pexels-photo-1775043.jpeg?auto=compress&cs=tinysrgb&w=300',
    },
    {
      id: 9,
      name: 'مافن التوت',
      nameEn: 'Blueberry Muffin',
      price: 15,
      category: 'pastry',
      description: 'مافن التوت الطازج',
      image: 'https://images.pexels.com/photos/2067396/pexels-photo-2067396.jpeg?auto=compress&cs=tinysrgb&w=300',
      popular: true,
    },
    {
      id: 10,
      name: 'دونات',
      nameEn: 'Donut',
      price: 10,
      category: 'pastry',
      description: 'دونات محلى بالسكر',
      image: 'https://images.pexels.com/photos/1191639/pexels-photo-1191639.jpeg?auto=compress&cs=tinysrgb&w=300',
    },
  ];

  const categories = [
    { id: 'all', name: 'الكل', nameEn: 'All' },
    { id: 'hot', name: 'مشروبات ساخنة', nameEn: 'Hot Drinks' },
    { id: 'cold', name: 'مشروبات باردة', nameEn: 'Cold Drinks' },
    { id: 'pastry', name: 'مخبوزات', nameEn: 'Pastries' },
  ];

  const filteredItems = menuItems.filter(item => {
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.nameEn.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-amber-800 mb-4">
            قائمة المشروبات والمخبوزات
          </h1>
          <p className="text-lg text-amber-600 max-w-2xl mx-auto">
            اكتشف تشكيلتنا الواسعة من المشروبات الساخنة والباردة والمخبوزات الطازجة
          </p>
        </div>

        {/* Search and Filter */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-amber-400 h-5 w-5" />
              <input
                type="text"
                placeholder="البحث في القائمة..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 rounded-full border-2 border-amber-200 focus:border-amber-400 focus:outline-none bg-white/80 backdrop-blur-sm"
              />
            </div>

            {/* Category Filter */}
            <div className="flex gap-2 flex-wrap">
              {categories.map(category => (
                <button
                  key={category.id}
                  onClick={() => setActiveCategory(category.id)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                    activeCategory === category.id
                      ? 'bg-amber-600 text-white shadow-lg'
                      : 'bg-white/80 text-amber-600 hover:bg-amber-100 border border-amber-200'
                  }`}
                >
                  {category.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Menu Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredItems.map(item => (
            <div
              key={item.id}
              className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden border border-amber-100 group"
            >
              <div className="relative">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                {item.popular && (
                  <div className="absolute top-3 right-3 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-medium">
                    الأكثر طلباً
                  </div>
                )}
              </div>
              
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-semibold text-amber-800">{item.name}</h3>
                  <span className="text-lg font-bold text-amber-600">{item.price} ج.م</span>
                </div>
                
                <p className="text-sm text-gray-600 mb-1">{item.nameEn}</p>
                <p className="text-sm text-amber-600 mb-4">{item.description}</p>
                
                <button
                  onClick={() => onAddToCart(item)}
                  className="w-full bg-gradient-to-r from-amber-600 to-amber-700 text-white py-2 px-4 rounded-full font-medium hover:from-amber-700 hover:to-amber-800 transition-all duration-200 flex items-center justify-center group"
                >
                  <Plus className="h-4 w-4 mr-2 group-hover:scale-110 transition-transform" />
                  إضافة للسلة
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-12">
            <p className="text-lg text-amber-600">لا توجد عناصر تطابق البحث</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Menu;