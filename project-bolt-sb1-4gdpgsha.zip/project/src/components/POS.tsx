import React, { useState } from 'react';
import { Minus, Plus, Trash2, CreditCard, Banknote, Receipt, User } from 'lucide-react';

interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
}

interface POSProps {
  cartItems: CartItem[];
  onUpdateQuantity: (id: number, quantity: number) => void;
  onRemoveFromCart: (id: number) => void;
  onClearCart: () => void;
}

const POS: React.FC<POSProps> = ({ cartItems, onUpdateQuantity, onRemoveFromCart, onClearCart }) => {
  const [customerName, setCustomerName] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [amountPaid, setAmountPaid] = useState('');
  const [showReceipt, setShowReceipt] = useState(false);
  const [lastOrder, setLastOrder] = useState<any>(null);

  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = subtotal * 0.14; // 14% tax
  const total = subtotal + tax;
  const change = paymentMethod === 'cash' ? Math.max(0, parseFloat(amountPaid) - total) : 0;

  const handleCheckout = () => {
    if (cartItems.length === 0) return;
    
    if (paymentMethod === 'cash' && parseFloat(amountPaid) < total) {
      alert('المبلغ المدفوع أقل من المطلوب');
      return;
    }

    const order = {
      id: Date.now(),
      items: cartItems,
      customer: customerName || 'زبون',
      subtotal,
      tax,
      total,
      paymentMethod,
      amountPaid: paymentMethod === 'cash' ? parseFloat(amountPaid) : total,
      change,
      date: new Date().toLocaleString('ar-EG'),
    };

    setLastOrder(order);
    setShowReceipt(true);
    onClearCart();
    setCustomerName('');
    setAmountPaid('');
  };

  if (showReceipt && lastOrder) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 py-8">
        <div className="max-w-md mx-auto">
          <div className="bg-white rounded-xl shadow-xl p-6 border-2 border-amber-200">
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold text-amber-800 mb-2">SPHINX CAFE</h2>
              <p className="text-sm text-gray-600">فاتورة ضريبية</p>
              <p className="text-xs text-gray-500">Tax Invoice</p>
            </div>

            <div className="border-t border-b border-gray-200 py-4 mb-4">
              <div className="flex justify-between text-sm mb-2">
                <span>رقم الطلب: {lastOrder.id}</span>
                <span>{lastOrder.date}</span>
              </div>
              <div className="text-sm">
                <span>العميل: {lastOrder.customer}</span>
              </div>
            </div>

            <div className="space-y-2 mb-4">
              {lastOrder.items.map((item: CartItem) => (
                <div key={item.id} className="flex justify-between text-sm">
                  <div className="flex-1">
                    <div>{item.name}</div>
                    <div className="text-gray-500">{item.quantity} × {item.price.toFixed(2)} ج.م</div>
                  </div>
                  <div className="font-medium">
                    {(item.price * item.quantity).toFixed(2)} ج.م
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-gray-200 pt-4 space-y-2">
              <div className="flex justify-between">
                <span>المجموع الفرعي:</span>
                <span>{lastOrder.subtotal.toFixed(2)} ج.م</span>
              </div>
              <div className="flex justify-between">
                <span>الضريبة (14%):</span>
                <span>{lastOrder.tax.toFixed(2)} ج.م</span>
              </div>
              <div className="flex justify-between font-bold text-lg border-t pt-2">
                <span>المجموع:</span>
                <span>{lastOrder.total.toFixed(2)} ج.م</span>
              </div>
              <div className="flex justify-between">
                <span>المدفوع:</span>
                <span>{lastOrder.amountPaid.toFixed(2)} ج.م</span>
              </div>
              {lastOrder.change > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>الباقي:</span>
                  <span>{lastOrder.change.toFixed(2)} ج.م</span>
                </div>
              )}
            </div>

            <div className="text-center mt-6 pt-4 border-t border-gray-200">
              <p className="text-sm text-gray-600">شكراً لزيارتكم</p>
              <p className="text-xs text-gray-500">Thank you for your visit</p>
            </div>

            <div className="flex gap-2 mt-6">
              <button
                onClick={() => setShowReceipt(false)}
                className="flex-1 bg-amber-600 text-white py-2 px-4 rounded-lg hover:bg-amber-700 transition-colors"
              >
                طلب جديد
              </button>
              <button
                onClick={() => window.print()}
                className="flex-1 bg-gray-600 text-white py-2 px-4 rounded-lg hover:bg-gray-700 transition-colors"
              >
                طباعة
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-amber-800 mb-2">نقاط البيع</h1>
          <p className="text-lg text-amber-600">Point of Sale System</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Cart Section */}
          <div className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-6 border border-amber-200">
            <h2 className="text-2xl font-bold text-amber-800 mb-6 flex items-center">
              <Receipt className="h-6 w-6 mr-2" />
              سلة المشتريات
            </h2>

            {cartItems.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-lg text-gray-500">السلة فارغة</p>
                <p className="text-sm text-gray-400">أضف عناصر من القائمة</p>
              </div>
            ) : (
              <div className="space-y-4">
                {cartItems.map(item => (
                  <div key={item.id} className="flex items-center justify-between p-4 bg-amber-50 rounded-lg">
                    <div className="flex-1">
                      <h3 className="font-medium text-amber-800">{item.name}</h3>
                      <p className="text-sm text-amber-600">{item.price.toFixed(2)} ج.م</p>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                        className="w-8 h-8 rounded-full bg-amber-200 hover:bg-amber-300 flex items-center justify-center transition-colors"
                      >
                        <Minus className="h-4 w-4 text-amber-700" />
                      </button>
                      
                      <span className="w-8 text-center font-medium">{item.quantity}</span>
                      
                      <button
                        onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                        className="w-8 h-8 rounded-full bg-amber-200 hover:bg-amber-300 flex items-center justify-center transition-colors"
                      >
                        <Plus className="h-4 w-4 text-amber-700" />
                      </button>
                      
                      <button
                        onClick={() => onRemoveFromCart(item.id)}
                        className="w-8 h-8 rounded-full bg-red-200 hover:bg-red-300 flex items-center justify-center transition-colors ml-2"
                      >
                        <Trash2 className="h-4 w-4 text-red-700" />
                      </button>
                    </div>
                    
                    <div className="text-right ml-4">
                      <span className="font-bold text-amber-800">
                        {(item.price * item.quantity).toFixed(2)} ج.م
                      </span>
                    </div>
                  </div>
                ))}

                <button
                  onClick={onClearCart}
                  className="w-full bg-red-100 text-red-700 py-2 px-4 rounded-lg hover:bg-red-200 transition-colors flex items-center justify-center"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  مسح السلة
                </button>
              </div>
            )}
          </div>

          {/* Payment Section */}
          <div className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg p-6 border border-amber-200">
            <h2 className="text-2xl font-bold text-amber-800 mb-6 flex items-center">
              <CreditCard className="h-6 w-6 mr-2" />
              الدفع
            </h2>

            {/* Customer Info */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-amber-700 mb-2">
                <User className="h-4 w-4 inline mr-1" />
                اسم العميل (اختياري)
              </label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="أدخل اسم العميل..."
                className="w-full px-4 py-2 border border-amber-200 rounded-lg focus:ring-2 focus:ring-amber-300 focus:border-transparent"
              />
            </div>

            {/* Payment Method */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-amber-700 mb-2">طريقة الدفع</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setPaymentMethod('cash')}
                  className={`p-3 rounded-lg border-2 transition-all flex items-center justify-center ${
                    paymentMethod === 'cash'
                      ? 'border-amber-500 bg-amber-50 text-amber-700'
                      : 'border-gray-200 hover:border-amber-300'
                  }`}
                >
                  <Banknote className="h-5 w-5 mr-2" />
                  نقدي
                </button>
                <button
                  onClick={() => setPaymentMethod('card')}
                  className={`p-3 rounded-lg border-2 transition-all flex items-center justify-center ${
                    paymentMethod === 'card'
                      ? 'border-amber-500 bg-amber-50 text-amber-700'
                      : 'border-gray-200 hover:border-amber-300'
                  }`}
                >
                  <CreditCard className="h-5 w-5 mr-2" />
                  بطاقة
                </button>
              </div>
            </div>

            {/* Amount Paid (for cash) */}
            {paymentMethod === 'cash' && (
              <div className="mb-6">
                <label className="block text-sm font-medium text-amber-700 mb-2">المبلغ المدفوع</label>
                <input
                  type="number"
                  value={amountPaid}
                  onChange={(e) => setAmountPaid(e.target.value)}
                  placeholder="أدخل المبلغ المدفوع..."
                  className="w-full px-4 py-2 border border-amber-200 rounded-lg focus:ring-2 focus:ring-amber-300 focus:border-transparent"
                />
              </div>
            )}

            {/* Bill Summary */}
            <div className="bg-amber-50 p-4 rounded-lg mb-6">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>المجموع الفرعي:</span>
                  <span>{subtotal.toFixed(2)} ج.م</span>
                </div>
                <div className="flex justify-between">
                  <span>الضريبة (14%):</span>
                  <span>{tax.toFixed(2)} ج.م</span>
                </div>
                <div className="flex justify-between font-bold text-lg border-t pt-2">
                  <span>المجموع:</span>
                  <span>{total.toFixed(2)} ج.م</span>
                </div>
                {paymentMethod === 'cash' && amountPaid && (
                  <>
                    <div className="flex justify-between">
                      <span>المدفوع:</span>
                      <span>{parseFloat(amountPaid).toFixed(2)} ج.م</span>
                    </div>
                    <div className="flex justify-between text-green-600">
                      <span>الباقي:</span>
                      <span>{change.toFixed(2)} ج.م</span>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Checkout Button */}
            <button
              onClick={handleCheckout}
              disabled={cartItems.length === 0}
              className="w-full bg-gradient-to-r from-amber-600 to-amber-700 text-white py-3 px-6 rounded-lg font-semibold text-lg hover:from-amber-700 hover:to-amber-800 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              إتمام الطلب
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default POS;