import React, { useState } from 'react';
import { BarChart3, TrendingUp, Users, Coffee, DollarSign, Calendar, Eye, ShoppingCart } from 'lucide-react';

const Dashboard: React.FC = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('today');

  // Mock data - في التطبيق الحقيقي ستأتي من قاعدة البيانات
  const todayStats = {
    revenue: 2450,
    orders: 89,
    customers: 67,
    avgOrderValue: 27.5,
  };

  const monthlyStats = {
    revenue: 73500,
    orders: 2670,
    customers: 1890,
    avgOrderValue: 27.5,
  };

  const stats = selectedPeriod === 'today' ? todayStats : monthlyStats;

  const popularItems = [
    { name: 'كابتشينو', sales: 145, revenue: 2900 },
    { name: 'لاتيه', sales: 120, revenue: 2640 },
    { name: 'إسبريسو', sales: 98, revenue: 1470 },
    { name: 'فرابيه', sales: 87, revenue: 2436 },
    { name: 'مافن التوت', sales: 76, revenue: 1140 },
  ];

  const recentOrders = [
    { id: 1701234567, customer: 'أحمد محمد', total: 45.5, time: '10:30 ص', status: 'completed' },
    { id: 1701234568, customer: 'فاطمة علي', total: 32.0, time: '10:25 ص', status: 'completed' },
    { id: 1701234569, customer: 'محمد أحمد', total: 28.5, time: '10:20 ص', status: 'pending' },
    { id: 1701234570, customer: 'سارة محمود', total: 51.0, time: '10:15 ص', status: 'completed' },
    { id: 1701234571, customer: 'عمر حسن', total: 23.5, time: '10:10 ص', status: 'completed' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-amber-800 mb-2">لوحة التحكم</h1>
          <p className="text-lg text-amber-600">نظرة عامة على أداء الكافيه</p>
        </div>

        {/* Period Selection */}
        <div className="mb-8 flex gap-4">
          <button
            onClick={() => setSelectedPeriod('today')}
            className={`px-6 py-2 rounded-lg font-medium transition-all ${
              selectedPeriod === 'today'
                ? 'bg-amber-600 text-white shadow-lg'
                : 'bg-white text-amber-600 hover:bg-amber-50 border border-amber-200'
            }`}
          >
            اليوم
          </button>
          <button
            onClick={() => setSelectedPeriod('month')}
            className={`px-6 py-2 rounded-lg font-medium transition-all ${
              selectedPeriod === 'month'
                ? 'bg-amber-600 text-white shadow-lg'
                : 'bg-white text-amber-600 hover:bg-amber-50 border border-amber-200'
            }`}
          >
            هذا الشهر
          </button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-amber-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-amber-600">إجمالي المبيعات</p>
                <p className="text-2xl font-bold text-amber-800">{stats.revenue.toLocaleString()} ج.م</p>
              </div>
              <div className="bg-amber-100 p-3 rounded-full">
                <DollarSign className="h-6 w-6 text-amber-600" />
              </div>
            </div>
            <div className="flex items-center mt-2">
              <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
              <span className="text-sm text-green-600">+12.5%</span>
            </div>
          </div>

          <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-amber-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-amber-600">عدد الطلبات</p>
                <p className="text-2xl font-bold text-amber-800">{stats.orders}</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <ShoppingCart className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="flex items-center mt-2">
              <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
              <span className="text-sm text-green-600">+8.2%</span>
            </div>
          </div>

          <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-amber-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-amber-600">العملاء</p>
                <p className="text-2xl font-bold text-amber-800">{stats.customers}</p>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <Users className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <div className="flex items-center mt-2">
              <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
              <span className="text-sm text-green-600">+15.3%</span>
            </div>
          </div>

          <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-amber-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-amber-600">متوسط الطلب</p>
                <p className="text-2xl font-bold text-amber-800">{stats.avgOrderValue} ج.م</p>
              </div>
              <div className="bg-purple-100 p-3 rounded-full">
                <BarChart3 className="h-6 w-6 text-purple-600" />
              </div>
            </div>
            <div className="flex items-center mt-2">
              <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
              <span className="text-sm text-green-600">+3.7%</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Popular Items */}
          <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-amber-200">
            <h2 className="text-xl font-bold text-amber-800 mb-6 flex items-center">
              <Coffee className="h-5 w-5 mr-2" />
              المنتجات الأكثر مبيعاً
            </h2>
            <div className="space-y-4">
              {popularItems.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-amber-600 text-white rounded-full flex items-center justify-center text-sm font-bold mr-3">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium text-amber-800">{item.name}</p>
                      <p className="text-sm text-amber-600">{item.sales} مبيعة</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-amber-800">{item.revenue} ج.م</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Orders */}
          <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-amber-200">
            <h2 className="text-xl font-bold text-amber-800 mb-6 flex items-center">
              <Calendar className="h-5 w-5 mr-2" />
              الطلبات الأخيرة
            </h2>
            <div className="space-y-4">
              {recentOrders.map((order) => (
                <div key={order.id} className="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
                  <div>
                    <p className="font-medium text-amber-800">#{order.id}</p>
                    <p className="text-sm text-amber-600">{order.customer}</p>
                    <p className="text-xs text-gray-500">{order.time}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-amber-800">{order.total} ج.م</p>
                    <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${
                      order.status === 'completed' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {order.status === 'completed' ? 'مكتمل' : 'قيد التحضير'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
            <button className="w-full mt-4 text-center text-amber-600 hover:text-amber-800 font-medium flex items-center justify-center">
              <Eye className="h-4 w-4 mr-1" />
              عرض جميع الطلبات
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;