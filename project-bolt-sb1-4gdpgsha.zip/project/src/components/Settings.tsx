import React, { useState } from 'react';
import { Settings as SettingsIcon, User, Store, Printer, Palette, Globe, Save } from 'lucide-react';

const Settings: React.FC = () => {
  const [activeTab, setActiveTab] = useState('general');
  const [settings, setSettings] = useState({
    storeName: 'SPHINX CAFE',
    storeAddress: 'شارع الهرم، الجيزة، مصر',
    storePhone: '+20 2 1234 5678',
    storeEmail: 'info@sphinxcafe.com',
    currency: 'EGP',
    taxRate: 14,
    language: 'ar',
    theme: 'amber',
    printerEnabled: true,
    receiptFooter: 'شكراً لزيارتكم - Thank you for your visit',
  });

  const tabs = [
    { id: 'general', name: 'عام', icon: Store },
    { id: 'appearance', name: 'المظهر', icon: Palette },
    { id: 'printing', name: 'الطباعة', icon: Printer },
    { id: 'localization', name: 'اللغة والعملة', icon: Globe },
  ];

  const handleSave = () => {
    // Save settings to localStorage or send to backend
    localStorage.setItem('sphinxCafeSettings', JSON.stringify(settings));
    alert('تم حفظ الإعدادات بنجاح');
  };

  const handleInputChange = (field: string, value: string | number | boolean) => {
    setSettings(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-amber-800 mb-2 flex items-center">
            <SettingsIcon className="h-8 w-8 mr-3" />
            الإعدادات
          </h1>
          <p className="text-lg text-amber-600">إدارة إعدادات النظام والكافيه</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg border border-amber-200 p-4">
              <nav className="space-y-2">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full text-right px-4 py-3 rounded-lg transition-all flex items-center ${
                        activeTab === tab.id
                          ? 'bg-amber-600 text-white shadow-lg'
                          : 'text-amber-700 hover:bg-amber-50'
                      }`}
                    >
                      <Icon className="h-5 w-5 ml-3" />
                      {tab.name}
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>

          {/* Content */}
          <div className="lg:col-span-3">
            <div className="bg-white/90 backdrop-blur-sm rounded-xl shadow-lg border border-amber-200 p-6">
              
              {activeTab === 'general' && (
                <div>
                  <h2 className="text-2xl font-bold text-amber-800 mb-6">الإعدادات العامة</h2>
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-amber-700 mb-2">اسم المحل</label>
                      <input
                        type="text"
                        value={settings.storeName}
                        onChange={(e) => handleInputChange('storeName', e.target.value)}
                        className="w-full px-4 py-2 border border-amber-200 rounded-lg focus:ring-2 focus:ring-amber-300 focus:border-transparent"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-amber-700 mb-2">عنوان المحل</label>
                      <textarea
                        value={settings.storeAddress}
                        onChange={(e) => handleInputChange('storeAddress', e.target.value)}
                        rows={3}
                        className="w-full px-4 py-2 border border-amber-200 rounded-lg focus:ring-2 focus:ring-amber-300 focus:border-transparent"
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-amber-700 mb-2">رقم الهاتف</label>
                        <input
                          type="tel"
                          value={settings.storePhone}
                          onChange={(e) => handleInputChange('storePhone', e.target.value)}
                          className="w-full px-4 py-2 border border-amber-200 rounded-lg focus:ring-2 focus:ring-amber-300 focus:border-transparent"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-amber-700 mb-2">البريد الإلكتروني</label>
                        <input
                          type="email"
                          value={settings.storeEmail}
                          onChange={(e) => handleInputChange('storeEmail', e.target.value)}
                          className="w-full px-4 py-2 border border-amber-200 rounded-lg focus:ring-2 focus:ring-amber-300 focus:border-transparent"
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-amber-700 mb-2">نسبة الضريبة (%)</label>
                      <input
                        type="number"
                        value={settings.taxRate}
                        onChange={(e) => handleInputChange('taxRate', parseFloat(e.target.value))}
                        className="w-full px-4 py-2 border border-amber-200 rounded-lg focus:ring-2 focus:ring-amber-300 focus:border-transparent"
                      />
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'appearance' && (
                <div>
                  <h2 className="text-2xl font-bold text-amber-800 mb-6">المظهر والألوان</h2>
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-amber-700 mb-2">نظام الألوان</label>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {[
                          { id: 'amber', name: 'ذهبي', color: 'bg-amber-500' },
                          { id: 'orange', name: 'برتقالي', color: 'bg-orange-500' },
                          { id: 'brown', name: 'بني', color: 'bg-amber-800' },
                          { id: 'green', name: 'أخضر', color: 'bg-green-500' },
                        ].map((theme) => (
                          <button
                            key={theme.id}
                            onClick={() => handleInputChange('theme', theme.id)}
                            className={`p-4 rounded-lg border-2 transition-all ${
                              settings.theme === theme.id
                                ? 'border-amber-500 bg-amber-50'
                                : 'border-gray-200 hover:border-amber-300'
                            }`}
                          >
                            <div className={`w-8 h-8 ${theme.color} rounded-full mx-auto mb-2`}></div>
                            <span className="text-sm font-medium">{theme.name}</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'printing' && (
                <div>
                  <h2 className="text-2xl font-bold text-amber-800 mb-6">إعدادات الطباعة</h2>
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-medium text-amber-800">تفعيل الطباعة</h3>
                        <p className="text-sm text-amber-600">تفعيل طباعة الفواتير تلقائياً</p>
                      </div>
                      <button
                        onClick={() => handleInputChange('printerEnabled', !settings.printerEnabled)}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                          settings.printerEnabled ? 'bg-amber-600' : 'bg-gray-200'
                        }`}
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                            settings.printerEnabled ? 'translate-x-6' : 'translate-x-1'
                          }`}
                        />
                      </button>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-amber-700 mb-2">نص نهاية الفاتورة</label>
                      <textarea
                        value={settings.receiptFooter}
                        onChange={(e) => handleInputChange('receiptFooter', e.target.value)}
                        rows={3}
                        className="w-full px-4 py-2 border border-amber-200 rounded-lg focus:ring-2 focus:ring-amber-300 focus:border-transparent"
                        placeholder="النص الذي سيظهر في نهاية الفاتورة..."
                      />
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'localization' && (
                <div>
                  <h2 className="text-2xl font-bold text-amber-800 mb-6">اللغة والعملة</h2>
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-amber-700 mb-2">اللغة</label>
                        <select
                          value={settings.language}
                          onChange={(e) => handleInputChange('language', e.target.value)}
                          className="w-full px-4 py-2 border border-amber-200 rounded-lg focus:ring-2 focus:ring-amber-300 focus:border-transparent"
                        >
                          <option value="ar">العربية</option>
                          <option value="en">English</option>
                          <option value="fr">Français</option>
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-amber-700 mb-2">العملة</label>
                        <select
                          value={settings.currency}
                          onChange={(e) => handleInputChange('currency', e.target.value)}
                          className="w-full px-4 py-2 border border-amber-200 rounded-lg focus:ring-2 focus:ring-amber-300 focus:border-transparent"
                        >
                          <option value="EGP">جنيه مصري (EGP)</option>
                          <option value="USD">دولار أمريكي (USD)</option>
                          <option value="EUR">يورو (EUR)</option>
                          <option value="SAR">ريال سعودي (SAR)</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Save Button */}
              <div className="mt-8 pt-6 border-t border-amber-200">
                <button
                  onClick={handleSave}
                  className="bg-gradient-to-r from-amber-600 to-amber-700 text-white px-6 py-3 rounded-lg font-semibold hover:from-amber-700 hover:to-amber-800 transition-all duration-200 flex items-center"
                >
                  <Save className="h-5 w-5 mr-2" />
                  حفظ الإعدادات
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;