import React, { useState } from 'react';
import { Menu, X, Coffee, ShoppingCart, Settings, BarChart3 } from 'lucide-react';

interface NavigationProps {
  currentView: string;
  onViewChange: (view: string) => void;
  cartItems: number;
}

const Navigation: React.FC<NavigationProps> = ({ currentView, onViewChange, cartItems }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'الرئيسية', icon: Coffee },
    { id: 'menu', label: 'القائمة', icon: Menu },
    { id: 'pos', label: 'نقاط البيع', icon: ShoppingCart },
    { id: 'dashboard', label: 'لوحة التحكم', icon: BarChart3 },
    { id: 'settings', label: 'الإعدادات', icon: Settings },
  ];

  return (
    <nav className="bg-gradient-to-r from-amber-900 via-amber-800 to-amber-900 shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Coffee className="h-8 w-8 text-amber-300 mr-2" />
              <span className="text-2xl font-bold text-amber-100 tracking-wide">SPHINX</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4 rtl:space-x-reverse">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => onViewChange(item.id)}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 flex items-center ${
                      currentView === item.id
                        ? 'bg-amber-700 text-amber-100 shadow-inner'
                        : 'text-amber-200 hover:bg-amber-700 hover:text-amber-100'
                    }`}
                  >
                    <Icon className="h-4 w-4 mr-2" />
                    {item.label}
                    {item.id === 'pos' && cartItems > 0 && (
                      <span className="ml-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                        {cartItems}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-amber-200 hover:text-amber-100 hover:bg-amber-700 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-amber-500"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-amber-800">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onViewChange(item.id);
                    setIsMenuOpen(false);
                  }}
                  className={`block px-3 py-2 rounded-md text-base font-medium w-full text-right transition-all duration-200 flex items-center justify-end ${
                    currentView === item.id
                      ? 'bg-amber-700 text-amber-100'
                      : 'text-amber-200 hover:bg-amber-700 hover:text-amber-100'
                  }`}
                >
                  {item.label}
                  <Icon className="h-4 w-4 ml-2" />
                  {item.id === 'pos' && cartItems > 0 && (
                    <span className="mr-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                      {cartItems}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navigation;